C++ Library API of Rabit
========================
This page contains document of Library API of rabit.

```eval_rst
.. toctree::

.. doxygennamespace:: rabit
```
